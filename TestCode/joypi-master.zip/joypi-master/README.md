joypi
=====

scripts to control gpio and other stuff off a consumer joystick on the raspberry pi

run with:
sudo python joypi.py
