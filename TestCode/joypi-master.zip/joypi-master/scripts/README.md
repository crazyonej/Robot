these scripts are to be added to /etc/rc.local to enable them at boot

example 

   python /root/joypi/scripts/bootled.py &

   exit 0
